#pragma once

int InvokeCreateSvcRpcMain(char* pExecCmd);